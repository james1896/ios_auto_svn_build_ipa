# -*- coding: utf-8 -*-
setting={
   

    'svn': '/Applications/Xcode.app/Contents/Developer/usr/bin/',  # svn的程序所在路径 ***注意路径问题***
    'url': 'svn://XX.XX.XX.XXX:XXX/codes/app/',  # svn地址

    'user': '',
    'pwd': '',  # 密码
    'dist': '/Desktop/a1/',  # 目标地址
    'interval': 5  # 更新时间
}



class options:
    project=None
    workspace='/Users/toby/Desktop/auto_working/svn_workspace/ios/2017-05-23-14-09-1495519769/working/IosClient/IosClient.xcworkspace'
    scheme='IosClient'
    url='m.a02.com'
    bundleId=''
    bundleVersion='1.0'
    title="app name"
