# -*- coding:utf-8 -*-
require 'xcodeproj'

def dir_scanner(path)
	path = path+'/**/*.{c,m,cpp,h}';
	list = Dir.glob(path);
	list
end

def main
	basePath = '.';
	appName = 'app';
	if $*.length == 2 then
		basePath = $*[0];
		appName = $*[1];
	end

	puts "脚本路劲"+basePath;

	agqjPath = basePath+"/#{appName}/AGQJ";
	projectPath = basePath+"/#{appName}.xcodeproj";
	list = dir_scanner(agqjPath);
	
	project = Xcodeproj::Project.open(projectPath);
	target = project.targets.first;
	group = project.main_group.find_subpath(File.join('agqj', 'Game', 'Classes', 'UIKit'), true);
	group.set_source_tree('SOURCE_ROOT');

	refFiles = []
	list.each do |file|
		file_ref = group.new_reference(file);
		refFiles.push(file_ref);
	end

	target.add_file_references(refFiles);
	
	project.save();
	puts "文件导入完毕";
end

main();