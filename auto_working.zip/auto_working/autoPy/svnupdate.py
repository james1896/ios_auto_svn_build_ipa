# -*- coding: utf-8 -*-
import time,os,sys,config

import shutil

import svn.remote

dist=config.setting['dist']
os.chdir(config.setting['svn'])

def checkout(scheme):

    dirPath = '/Users/toby/Desktop/auto_working/svn_workspace/ios/%s' % time.strftime('%Y-%m-%d-%H-%M-%s',time.localtime())

    try:
        # checkout
        if os.path.exists('/tmp/working'):
            shutil.rmtree("/tmp/working")

        if os.path.exists('/tmp/working1'):
            shutil.rmtree("/tmp/working1")

        # checkout主目录
        r = svn.remote.RemoteClient(config.setting['url'],config.setting['user'],config.setting['pwd'])
        r.export('/tmp/working')
        
        # checkout子目录
        r = svn.remote.RemoteClient(config.setting['sub_url_1'], config.setting['user'], config.setting['pwd'])
        r.export('/tmp/working1/%s/%s' %(scheme,scheme))
        moveDir('/tmp/working1/%s/%s' %(scheme,scheme), '/tmp/working/%s/%s/AGQJ' %(scheme,scheme))

        # 移动到桌面自动打包工作区
        os.mkdir(dirPath, 0777)
        shutil.move('/tmp/working/', dirPath)
        print 'checkout success - dirPath:', dirPath

        buildProject(dirPath+'/working/%s' %(scheme), scheme)


    except Exception,e:
        print 'Exception',e


    return dirPath+'/working/%s/%s.xcworkspace' %(scheme, scheme)

execPath = ''

def moveDir(src, dst):
    list = os.listdir(src)
    for sub in list:
        shutil.copy(src+'/'+sub, dst)


def buildProject(path, scheme):
    rubyPath = execPath+'/main.rb'
    cmd = 'ruby %s %s %s' %(rubyPath, path, scheme)
    os.system(cmd)